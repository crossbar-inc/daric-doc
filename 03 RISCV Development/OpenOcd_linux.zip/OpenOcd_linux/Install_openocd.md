## 1. Clone the Source Code
https://github.com/SpinalHDL/openocd_riscv

## 2. Use the Recommended Revision

commit 058dfa50d625893bee9fecf8d604141911fac125 (HEAD -> riscv_spinal, origin/riscv_spinal, origin/HEAD)
Author: Dolu1990 <charles.papon.90@gmail.com>
Date:   Tue Nov 29 14:50:17 2022 +0100

    riscv : Add support for run_algorytm memory parameters

    Change-Id: I35c8e74422b01549d0b203a848f907b7d60c9296
    Signed-off-by: Dolu1990 <charles.papon.90@gmail.com>

## 3. Prepare the Build Environment
Install dependencies on Ubuntu 14:

```sh
sudo apt-get install libtool automake libusb-1.0.0-dev texinfo libusb-dev libyaml-dev pkg-config
```

Build:

```sh
./bootstrap
./configure --enable-ftdi --enable-dummy
make
#sudo make install
```

If you are using a J-Link debugger, make sure J-Link support is enabled during `./configure`.
```sh
./configure --prefix=/usr/local --enable-jlink 
```


## 4. Configuration File Overview

- `cramsoc.cfg`: Board-level OpenOCD configuration for the CramSoC platform.
- `jlink.cfg`: Auxiliary J-Link interface configuration. Since `cramsoc.cfg` already includes `adapter driver jlink`, this file is generally not required as a standalone load.
- `VexRiscv_CramSoC.yaml`: CPU description file used during VexRiscv target initialization.

## 5. Remote Connection Troubleshooting (Connection Failed)

If a remote host runs `telnet 172.20.182.48 4444` and receives a `Connection failed` error:

- **Root cause**: OpenOCD listens on `localhost` by default, blocking access from other hosts on the network.
- **Fix**: Add `bindto 0.0.0.0` to `board/cramsoc.cfg` before the `init` directive.

Client connection example:

```bash
telnet 172.20.182.48 4444
```

If the connection still fails, temporarily open the required ports on the server (as needed):

```bash
sudo ufw allow 4444/tcp
sudo ufw allow 3333/tcp
sudo ufw allow 6666/tcp
```

GDB remote connection example:
```bash
riscv-none-elf-gdb /path/to/your.elf
# Once inside GDB:
(gdb) target extended-remote 172.20.182.48:3333
(gdb) monitor reset halt
(gdb) load
```

## 6. Connect with GDB
riscv-none-elf-gdb -ex "target extended-remote :3333"

## 7. GDB Test Commands
mon reset halt
x/32x 0x61080000
restore boot.bin binary 0x61080000
x/32x 0x61080000
set $pc=0x61080000

