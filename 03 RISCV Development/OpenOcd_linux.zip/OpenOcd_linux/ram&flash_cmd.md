OpenOCD RAM & FLASH Command Manual

# 1. Connect to OpenOCD

telnet 127.0.0.1 4444  
or  
openocd -f board/cramsoc.cfg

# 2. RAM Operations

## 2.1 Read Memory
mdw <address> <count>  
Example: Read 4 words (32-bit) starting from 0x80000000  
mdw 0x80000000 4  
mdw 0x60400180 32

## 2.2 Write Memory
mww <address> <value>  
Example: Write 0x12345678 to 0x80000000  
mww 0x80000000 0x12345678

## 2.3 Write Multiple Values to Memory
mww <address> <value1> <value2> ...  
Example: mww 0x80000000 0x1 0x2 0x3

## 2.4 Write BIN File to RAM

OpenOCD supports writing binary (BIN) files directly to RAM.

### Usage:
load_image <bin file path> <start address> bin

Example: Write daric_rdemo.bin to 0x61100000  
load_image daric_rdemo.bin 0x61100000 bin

You can also use dump_image to export memory contents to a file.
dump_image test.bin 0x61100000 128


Note:
- The BIN file will be written byte-by-byte to the specified address. Make sure the target address is a writable RAM region.
- If the target RAM needs initialization (e.g., SDRAM), run the initialization script first.
- load_image can also be used for HEX/ELF files; for bin format, add the bin parameter.


# 3. FLASH Operations

## 3.1 View Registered Flash Banks
flash banks

## 3.2 Probe/Initialize Flash
flash probe <num>  
Example: flash probe 0

## 3.3 Erase Flash (reram not support erase)
flash erase_address <address> <length>  
Example: Erase 0x10000 bytes starting from 0x60000000  
flash erase_address 0x60000000 0x10000

Or erase all by bank  
flash erase_sector <num> 0 last  
Example: flash erase_sector 0 0 last

## 3.4 Write to Flash
flash write_image <filename> <address>  
Example: 
flash write_image daric_demo.bin 0x60000000  
flash read_bank 0 test.bin 0x000 0x1000

flash verify_image daric_rdemo.bin 0x60080000 //no support

## 3.5 Verify Flash
flash verify_image <filename> <address>  
Example: flash verify_image my.bin 0x60000000

## 3.6 Read Flash to File
flash read_bank <num> <filename> <offset> <length>  
Example: 
flash read_bank 0 test.bin 0x000 0x1000

Reset and halt: reset halt  
Reset and run: reset run  
Exit telnet: quit  
Shutdown OpenOCD: shutdown


# 5. Notes

- <num> is the bank number shown by the flash banks command
- <address>, <offset>, <length> support hexadecimal with 0x prefix



If you need custom command templates or scripts for your board/SoC, please specify.