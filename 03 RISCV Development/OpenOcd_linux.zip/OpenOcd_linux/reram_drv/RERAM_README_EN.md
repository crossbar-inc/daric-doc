# ReRAM Flash Driver for OpenOCD (English)

## Overview

This is a ReRAM (Resistive Memory) storage driver created for OpenOCD. It supports read and write operations for ReRAM storage devices.

## Features

- **Storage Address Range**: 0x60000000 - 0x603D9FFF
- **Block Size**: 256 bits (32 bytes)
- **Operation Mode**: No erase, read-through, write-only
- **Write Policy**: Requires switching modes via control register and sending command sequences

## Storage Configuration

| Parameter | Value |
|-----------|-------|
| Start Address | 0x60000000 |
| End Address | 0x603D9FFF |
| Total Size | 3,932,160 bytes (~3.75 MB) |
| Block Size | 32 bytes (256 bits) |
| Total Blocks | 122,880 |
| Control Register (RRCCR) | 0x40000000 |

## Register Description

### RRCCR (ReRAM Control Register) - 0x40000000

- **Data Mode**: Write 0x00000000
- **Command Mode**: Write 0x00000002

### Commands

- **LOAD Command**: 0x00005200 - Transfers 256-bit data from BUFFER1 to BUFFER2
- **WRITE Command**: 0x00009528 - Writes data from BUFFER2 to the ReRAM storage area

## Write Operation Procedure

1. **Data Loading**: Write 256 bits (32 bytes) of data to the block start address
2. **Switch to Command Mode**: Write 0x40000000 = 0x00000002
3. **Execute LOAD Command**: Write `<block start address>` = 0x00005200
4. **Execute WRITE Command**: Write `<block start address>` = 0x00009528
5. **Wait**: Wait 2ms for the write operation to complete
6. **Switch Back to Data Mode**: Write 0x40000000 = 0x00000000

## Configuration Example

### OpenOCD Configuration File (.cfg)

```tcl
# Configure ReRAM storage
flash bank reram 0x60000000 0x3D9FFF 1 4 $_TARGETNAME
```

Parameter description:
- `0x60000000`: Base address
- `0x3D9FFF`: Size (bytes)
- `1`: Chip width (bytes)
- `4`: Bus width (bytes)
- `$_TARGETNAME`: Target device name

## Usage

### Writing Data

```tcl
# Write 32 bytes to address 0x60000000
flash write_image [binary format a* <data>] 0x60000000 bin
flash write_image [binary format a* <data>] 0x60000000 daric_rdemo.bin

flash write_image daric_rdemo.bin 0x60000000 bin
```

Or in the OpenOCD command line:

```tcl
flash write_bank reram 0 <data file> 0
flash write_bank reram 0 daric_rdemo.bin 0
```

### Reading Data

```tcl
# Read 32 bytes of data
dump_image <output file> 0x60000000 32
dump_image test.bin 0x60000000 32

dump_image test.bin 0x60400180 32
```

### Probing the Memory

```tcl
flash probe reram
```

## File List

- `src/flash/nor/reram.c` - ReRAM driver implementation
- `src/flash/nor/Makefile.am` - Updated to include reram.c
- `src/flash/nor/drivers.c` - Updated to register the reram driver

## Compilation

The ReRAM driver is integrated into the OpenOCD build system. To compile OpenOCD with ReRAM support:

```bash
./configure --enable-ftdi
make
make install
```

## Limitations

1. **No Erase Support**: ReRAM does not support block erase operations
2. **Alignment Requirement**: Write operations must be aligned to 32 bytes (256 bits)
3. **Block Size**: All write operations must be multiples of 32 bytes
4. **Sequential Write**: Write operations must follow the defined step sequence

## Error Handling

The driver provides detailed error checking:

- `ERROR_FLASH_DST_OUT_OF_BANK`: Write exceeds storage range
- `ERROR_FLASH_DST_BREAKS_ALIGNMENT`: Write address or size is not aligned
- `ERROR_OK`: Attempt to perform an unsupported operation - (such as erase)

## Debugging

Enable OpenOCD debugging to view detailed operation logs:

```tcl
debug_level 3
```

## Technical Support

For issues regarding the ReRAM driver, please refer to:
- Relevant hardware documentation
- OpenOCD official documentation: https://openocd.org
