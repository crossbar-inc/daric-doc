/***************************************************************************
 *   Copyright (C) 2024 ReRAM Storage Driver                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "imp.h"
#include <helper/time_support.h>

/* ReRAM storage configuration */
#define RERAM_START_ADDRESS		0x60000000
#define RERAM_END_ADDRESS		0x603D9FFF
#define RERAM_TOTAL_SIZE		(RERAM_END_ADDRESS - RERAM_START_ADDRESS + 1)
#define RERAM_BLOCK_SIZE		32		/* 256 bit = 32 bytes */
#define RERAM_NUM_BLOCKS		(RERAM_TOTAL_SIZE / RERAM_BLOCK_SIZE)

/* ReRAM control register */
#define RRCCR					0x40000000
#define RRCCR_MODE_DATA			0x00000000
#define RRCCR_MODE_CMD			0x00000002

/* ReRAM commands */
#define RERAM_CMD_LOAD			0x00005200
#define RERAM_CMD_WRITE			0x00009528

/* ReRAM write delay (2ms in milliseconds) */
#define RERAM_WRITE_DELAY_MS	2

struct reram_flash_bank {
	struct target *target;
	uint32_t start_address;
	uint32_t end_address;
};

static int reram_set_mode(struct flash_bank *bank, uint32_t mode)
{
	struct reram_flash_bank *info = bank->driver_priv;
	uint32_t value = mode;
	
	return target_write_u32(info->target, RRCCR, value);
}

static int reram_execute_command(struct flash_bank *bank, uint32_t address, uint32_t command)
{
	struct reram_flash_bank *info = bank->driver_priv;
	
	return target_write_u32(info->target, address, command);
}

static int reram_write_block(struct flash_bank *bank, const uint8_t *buffer, uint32_t address)
{
	struct reram_flash_bank *info = bank->driver_priv;
	int retval;
	int64_t start_time;
	
	/* Step 1: Data loading - write 256 bit (32 bytes) data to block start address */
	for (int i = 0; i < RERAM_BLOCK_SIZE; i += 4) {
		uint32_t data = buffer[i] | (buffer[i+1] << 8) | (buffer[i+2] << 16) | (buffer[i+3] << 24);
		retval = target_write_u32(info->target, address + i, data);
		if (retval != ERROR_OK)
			return retval;
	}
	
	/* Step 2: Switch to command mode */
	retval = reram_set_mode(bank, RRCCR_MODE_CMD);
	if (retval != ERROR_OK)
		return retval;
	
	/* Step 3: LOAD command - transfer BUFFER1 to BUFFER2 */
	retval = reram_execute_command(bank, address, RERAM_CMD_LOAD);
	if (retval != ERROR_OK)
		return retval;
	
	/* Step 4: WRITE command - write BUFFER2 to ReRAM storage */
	retval = reram_execute_command(bank, address, RERAM_CMD_WRITE);
	if (retval != ERROR_OK)
		return retval;
	
	/* Wait for 2ms for write to complete */
	/*start_time = timeval_ms();
	while (timeval_ms() - start_time <= RERAM_WRITE_DELAY_MS) {
		if ((timeval_ms() - start_time) >= RERAM_WRITE_DELAY_MS)
			break;
		usleep(100);
	}*/
	
	/* Step 5: Switch back to data mode */
	retval = reram_set_mode(bank, RRCCR_MODE_DATA);
	if (retval != ERROR_OK)
		return retval;
	
	return ERROR_OK;
}

/* flash bank reram <base> <size> <chip_width> <bus_width> <target#>
 */
FLASH_BANK_COMMAND_HANDLER(reram_flash_bank_command)
{
	struct reram_flash_bank *info;
	
	if (CMD_ARGC < 6)
		return ERROR_COMMAND_SYNTAX_ERROR;
	
	info = malloc(sizeof(struct reram_flash_bank));
	if (!info) {
		LOG_ERROR("no memory for ReRAM flash bank info");
		return ERROR_FAIL;
	}
	
	bank->driver_priv = info;
	
	/* Use RERAM_BLOCK_SIZE as the sector size */
	bank->num_sectors = RERAM_NUM_BLOCKS;
	bank->sectors = malloc(sizeof(struct flash_sector) * bank->num_sectors);
	if (!bank->sectors) {
		LOG_ERROR("no memory for ReRAM sectors");
		free(info);
		return ERROR_FAIL;
	}
	
	for (uint32_t i = 0; i < bank->num_sectors; i++) {
		bank->sectors[i].offset = i * RERAM_BLOCK_SIZE;
		bank->sectors[i].size = RERAM_BLOCK_SIZE;
		bank->sectors[i].is_erased = -1;
		bank->sectors[i].is_protected = 0;
	}
	
	info->target = get_target(CMD_ARGV[5]);
	if (!info->target) {
		LOG_ERROR("target '%s' not defined", CMD_ARGV[5]);
		free(bank->sectors);
		free(info);
		return ERROR_FAIL;
	}
	
	info->start_address = RERAM_START_ADDRESS;
	info->end_address = RERAM_END_ADDRESS;
	bank->base = info->start_address;
	bank->size = RERAM_TOTAL_SIZE;
	
	return ERROR_OK;
}

static int reram_erase(struct flash_bank *bank, unsigned int first, unsigned int last)
{
	/* ReRAM does not support erase operation */
	LOG_ERROR("ReRAM does not support erase operation");
	return ERROR_OK;
}

static int reram_write(struct flash_bank *bank, const uint8_t *buffer, uint32_t offset, uint32_t count)
{
	struct reram_flash_bank *info = bank->driver_priv;
	uint32_t address;
	uint32_t write_bytes;
	int retval;
	
	/* Check bounds */
	if ((offset + count) > bank->size) {
		LOG_ERROR("ReRAM write overflow: offset=0x%x, count=0x%x, size=0x%x",
			offset, count, bank->size);
		return ERROR_FLASH_DST_OUT_OF_BANK;
	}
	
	/* ReRAM requires 256-bit (32-byte) aligned writes */
	if ((offset % RERAM_BLOCK_SIZE) != 0) {
		LOG_ERROR("ReRAM write offset must be %d-byte aligned", RERAM_BLOCK_SIZE);
		return ERROR_FLASH_DST_BREAKS_ALIGNMENT;
	}
	
	// if ((count % RERAM_BLOCK_SIZE) != 0) {
	// 	LOG_ERROR("ReRAM write count must be %d-byte aligned", RERAM_BLOCK_SIZE);
	// 	return ERROR_FLASH_DST_BREAKS_ALIGNMENT;
	// }
	
	address = info->start_address + offset;
	write_bytes = 0;
	
	while (write_bytes < count) {
		LOG_INFO("ReRAM write: address=0x%x, block=%u/%u",
			address, write_bytes / RERAM_BLOCK_SIZE, count / RERAM_BLOCK_SIZE);
		
		uint8_t temp_buf[RERAM_BLOCK_SIZE];
   		uint32_t remain = count - write_bytes;
		if (remain >= RERAM_BLOCK_SIZE) {
			retval = reram_write_block(bank, buffer + write_bytes, address);
			if (retval != ERROR_OK) {
				LOG_ERROR("ReRAM write block failed at address 0x%x", address);
				return retval;
			}
		} else {
			memset(temp_buf, 0, RERAM_BLOCK_SIZE);
			memcpy(temp_buf, buffer + write_bytes, remain);
			retval = reram_write_block(bank, temp_buf, address);
			if (retval != ERROR_OK) {
				LOG_ERROR("ReRAM write block failed at address 0x%x", address);
				return retval;
			}
		}
		
		address += RERAM_BLOCK_SIZE;
		write_bytes += RERAM_BLOCK_SIZE;
	}
	
	LOG_INFO("ReRAM write complete: %d bytes written", count);
	return ERROR_OK;
}

static int reram_read(struct flash_bank *bank, uint8_t *buffer, uint32_t offset, uint32_t count)
{
	struct reram_flash_bank *info = bank->driver_priv;
	uint32_t address;
	
	/* Check bounds */
	if ((offset + count) > bank->size) {
		LOG_ERROR("ReRAM read overflow: offset=0x%x, count=0x%x, size=0x%x",
			offset, count, bank->size);
		return ERROR_FLASH_DST_OUT_OF_BANK;
	}
	
	address = info->start_address + offset;
	
	return target_read_buffer(info->target, address, count, buffer);
}

static int reram_probe(struct flash_bank *bank)
{
	struct reram_flash_bank *info = bank->driver_priv;
	
	if (!info->target) {
		LOG_ERROR("target not yet associated with ReRAM flash bank");
		return ERROR_FLASH_BANK_NOT_PROBED;
	}
	
	LOG_INFO("ReRAM flash bank probed successfully");
	LOG_INFO("  Start address: 0x%x", info->start_address);
	LOG_INFO("  End address:   0x%x", info->end_address);
	LOG_INFO("  Total size:    0x%x (%d bytes)", bank->size, bank->size);
	LOG_INFO("  Block size:    %d bytes (256 bits)", RERAM_BLOCK_SIZE);
	LOG_INFO("  Num sectors:   %d", bank->num_sectors);
	
	return ERROR_OK;
}

static int reram_auto_probe(struct flash_bank *bank)
{
	return reram_probe(bank);
}

static int reram_erase_check(struct flash_bank *bank)
{
	/* ReRAM does not support erase, so all sectors are considered not erased */
	for (unsigned int i = 0; i < bank->num_sectors; i++)
		bank->sectors[i].is_erased = 0;
	
	return ERROR_OK;
}

static int reram_info(struct flash_bank *bank, struct command_invocation *cmd)
{
	struct reram_flash_bank *info = bank->driver_priv;
	
	command_print_sameline(cmd, "\nReRAM flash driver\n");
	command_print_sameline(cmd, "  Start address: 0x%x\n", info->start_address);
	command_print_sameline(cmd, "  End address:   0x%x\n", info->end_address);
	command_print_sameline(cmd, "  Total size:    0x%x bytes\n", bank->size);
	command_print_sameline(cmd, "  Block size:    %d bytes (256 bits)\n", RERAM_BLOCK_SIZE);
	command_print_sameline(cmd, "  Num sectors:   %d\n", bank->num_sectors);
	
	return ERROR_OK;
}

static const struct command_registration reram_command_handlers[] = {
	{
		.name = "reram",
		.mode = COMMAND_ANY,
		.help = "ReRAM flash command group",
		.usage = "",
	},
	COMMAND_REGISTRATION_DONE
};

const struct flash_driver reram_flash = {
	.name = "reram",
	.usage = "flash bank reram <base> <size> <chip_width> <bus_width> <target#>",
	.commands = reram_command_handlers,
	.flash_bank_command = reram_flash_bank_command,
	.erase = reram_erase,
	.write = reram_write,
	.read = reram_read,
	.probe = reram_probe,
	.auto_probe = reram_auto_probe,
	.erase_check = reram_erase_check,
	.info = reram_info,
	.free_driver_priv = default_flash_free_driver_priv,
};
