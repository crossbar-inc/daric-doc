# ReRAM Flash Driver for OpenOCD

## 概述

这是为 OpenOCD 创建的 ReRAM (Resistive Memory) 存储驱动程序。支持 ReRAM 存储设备的读写操作。

## 特性

- **存储地址范围**: 0x60000000 - 0x603D9FFF
- **块大小**: 256 bit (32 bytes)
- **操作模式**: 无擦除，读直读（read-through），写专用
- **写策略**: 需要通过控制寄存器切换模式并发送命令序列

## 存储配置

| 参数 | 值 |
|-----|-----|
| 起始地址 | 0x60000000 |
| 结束地址 | 0x603D9FFF |
| 总大小 | 3,932,160 字节 (~3.75 MB) |
| 块大小 | 32 字节 (256 bit) |
| 总块数 | 122,880 |
| 控制寄存器 (RRCCR) | 0x40000000 |

## 寄存器说明

### RRCCR (ReRAM Control Register) - 0x40000000

- **数据模式**: 写入 0x00000000
- **命令模式**: 写入 0x00000002

### 命令

- **LOAD 命令**: 0x00005200 - 将 BUFFER1 中的 256bit 数据转移到 BUFFER2
- **WRITE 命令**: 0x00009528 - 将 BUFFER2 中的数据写入 ReRAM 存储区

## 写操作流程

1. **数据装载**: 将 256 bit (32 bytes) 数据写入到块起始地址
2. **切换到命令模式**: 写 0x40000000 = 0x00000002
3. **执行 LOAD 命令**: 写 `<块起始地址>` = 0x00005200
4. **执行 WRITE 命令**: 写 `<块起始地址>` = 0x00009528
5. **等待**: 等待 2ms 以让写操作完成
6. **切换回数据模式**: 写 0x40000000 = 0x00000000

## 配置示例

### OpenOCD 配置文件 (.cfg)

```tcl
# 配置 ReRAM 存储
flash bank reram 0x60000000 0x3D9FFF 1 4 $_TARGETNAME
```

参数说明:
- `0x60000000`: 基地址
- `0x3D9FFF`: 大小（字节）
- `1`: 芯片宽度（字节）
- `4`: 总线宽度（字节）
- `$_TARGETNAME`: 目标设备名称

## 使用方法

### 写入数据

```tcl
# 写入 32 字节到地址 0x60000000
flash write_image [binary format a* <data>] 0x60000000 bin
flash write_image [binary format a* <data>] 0x60000000 daric_rdemo.bin

flash write_image  daric_rdemo.bin 0x60000000 bin
```

或者在 OpenOCD 命令行中:

```tcl
flash write_bank reram 0 <数据文件> 0
flash write_bank reram 0 daric_rdemo.bin 0
```

### 读取数据

```tcl
# 读取 32 字节数据
dump_image <输出文件> 0x60000000 32
dump_image test.bin 0x60000000 32

dump_image test.bin 0x60400180 32
```

### 探测存储器

```tcl
flash probe reram
```

## 文件列表

- `src/flash/nor/reram.c` - ReRAM 驱动实现
- `src/flash/nor/Makefile.am` - 已更新以包含 reram.c
- `src/flash/nor/drivers.c` - 已更新以注册 reram 驱动

## 编译

ReRAM 驱动已集成到 OpenOCD 构建系统中。要编译包含 ReRAM 支持的 OpenOCD:

```bash
./configure --enable-ftdi
make
make install
```

## 限制

1. **不支持擦除**: ReRAM 不支持块擦除操作
2. **对齐要求**: 写操作必须以 32 字节（256 bit）对齐
3. **块大小**: 所有写操作必须是 32 字节的整数倍
4. **顺序写**: 必须按照定义的步骤顺序执行写操作

## 错误处理

驱动提供详细的错误检查:

- `ERROR_FLASH_DST_OUT_OF_BANK`: 写入超出存储范围
- `ERROR_FLASH_DST_BREAKS_ALIGNMENT`: 写入地址或大小未对齐
- `ERROR_OK;`: 尝试执行不支持的操作（例如擦除,兼容GDB调试）

## 调试

启用 OpenOCD 调试以查看详细的操作日志:

```tcl
debug_level 3
```

## 技术支持

有关 ReRAM 驱动的问题，请参考：
- 相关硬件文档
- OpenOCD 官方文档: https://openocd.org
